# This is a directory for course data

Files can be uploaded via command line or web portal

You can upload large files via git-lfs https://git-lfs.github.com
