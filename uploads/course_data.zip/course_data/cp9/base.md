backup of cp9 data
