import csv
import pprint

# for each sample, print out the lineage it is, the drugs it is resistant to, the genes responsible for those resistances, and the evidence underpinning the idenficiations of those genes.

class Sample:
    def __init__(self, record):
        self.name = record['sample']
        self.lineage = record['lineage']
        self.drug_susceptibility = {}
        self.drug_genes = {}

    def add_drug_susceptibility(self, record):
        self.drug_susceptibility[record['drug']] = record['susceptibility']

    def add_drug_genes(self, record):
        if record['genes'] != '':
            self.drug_genes[record['drug']] = []
            for gene in record['genes'].split(';'):
                gene_details = gene.split(':')
                self.drug_genes[record['drug']].extend([gene_details[0], int(gene_details[1]), int(gene_details[2])])


def read_infile(inhandle):
    with open(inhandle) as fi:
        records = csv.DictReader(fi)
        output = list(records)
        return output


def make_class_version(records):
    output_dict = {}
    for each_record in records:
        if each_record['sample'] in output_dict:
            output_dict[each_record['sample']].add_drug_susceptibility(each_record)
            output_dict[each_record['sample']].add_drug_genes(each_record)
            # output_dict[each_record['sample']].
        else:
            output_dict[each_record['sample']] = Sample(each_record)
            output_dict[each_record['sample']].add_drug_susceptibility(each_record)
            output_dict[each_record['sample']].add_drug_genes(each_record)
    return output_dict
    # for sample in output_dict:
        # output_dict[sample].


def class_print_suscept(output_dict):
    # for sample in output_dict:
        # print(output_dict[sample].name, output_dict[sample].drug_susceptibility)
    drugs = ['aminoglycosides', 'beta-lactamases', 'ESBLs', 'macrolides', 'phenicols', 'sulfonamides', 'tetracyclines', 'trimethoprims']
    for sample in output_dict:
        output = [sample]
        for drug in drugs:
            output.append(output_dict[sample].drug_susceptibility[drug])
            # print(sample, output_dict[drug]['susceptibility'])
        print(*output, sep = '\t')


def class_print_genes(output_dict):
    for sample in output_dict:
        # print(sample, output_dict[sample])
        for drug in output_dict[sample].drug_genes:
            output = [sample, drug]
            output.extend(output_dict[sample].drug_genes[drug])
            # print(drug, output_dict[sample][drug])
            print(*output, sep = '\t')
            

def main():
    '''
    1. read in results
    2. group by sample name
    '''
    inhandle = '/Users/flashton/Google Drive/training/KEMRI training/2023.03.21.advanced_python.custom_classes/typhi_mykrobe.training.csv'
    records = read_infile(inhandle)
    output_dict = make_class_version(records)
    # class_print_suscept(output_dict)
    class_print_genes(output_dict)
    # pprint.pprint(records)



if __name__ == '__main__':
    main()