import csv

def read_infile(inhandle):
    output = []
    with open(inhandle) as fi:
        records = csv.DictReader(fi)
        output = list(records)
    return output