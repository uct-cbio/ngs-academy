


scientists = ['Charles Darwin', 'George Washington Carver', 'Margaret Dayhoff', 'Marie Skłodowska Curie']

scientists = {'Charles Darwin': '1809-02-12', 'George Washington Carver': '1864', 'Margaret Dayhoff': '1925-03-11', 'Marie Skłodowska Curie': '1867-11-07'}

print(scientists['Charles Darwin'])



scientists = {'Charles Darwin': 
                {'DoB': '1809-02-12', 'PoB': 'UK'},
              'George Washington Carver': 
                {'DoB': '1864', 'PoB': 'USA'},
              'Margaret Dayhoff': 
                {'DoB': '1925-03-11', 'PoB': 'USA'},
              'Marie Skłodowska Curie': 
                {'DoB': '1867-11-07', 'PoB': 'Poland'}}

print(scientists['Charles Darwin']['DoB'])

# for name in scientists:
#     print(name, scientists[name])
#     for fact in scientists[name]:
#         print(scientists[name][fact])

scientists = {'Charles Darwin': 
                {'DoB': '1809-02-12', 'PoB': 
                        {'city': 'Shrewsbury', 'country': 'UK'}},
              'George Washington Carver': 
                {'DoB': '1864','PoB': 
                    {'city': 'Diamond', 'country': 'USA'}},
              'Margaret Dayhoff': 
                {'DoB': '1925-03-11', 'PoB': 
                    {'city': 'Philadelphia', 'country': 'USA'}},
              'Marie Skłodowska Curie': 
                {'DoB': '1867-11-07', 'PoB': 
                    {'city': 'Warsaw', 'country': 'Poland'}}}

print(scientists['Charles Darwin']['PoB']['country'])





scientists = {'Charles Darwin': 
                {'DoB': '1809-02-12',
                 'PoB': 
                    {'city': 'Shrewsbury', 'country': 
                        {'name': 'UK', 'population': 67330000}}},
              'George Washington Carver': 
                {'DoB': '1864',
                 'PoB': 
                    {'city': 'Diamond', 'country': 
                        {'name':'USA', 'population':331900000}}},
              'Margaret Dayhoff': 
                {'DoB': '1925-03-11',
                 'PoB': 
                    {'city': 'Philadelphia', 'country': 
                        {'name':'USA', 'population':331900000}}},
              'Marie Skłodowska Curie': 
                {'DoB': '1867-11-07',
                 'PoB': 
                    {'city': 'Warsaw', 'country': 
                        {'name':'Poland', 'population':37750000}}}
              }

print(scientists['Charles Darwin']['PoB']['country']['population'])

scientists['George Washington Carver']['PoB']['country']['population'] = 331900001
scientists['Margaret Dayhoff']['PoB']['country']['population'] = 331900001

class PlaceOfBirth:
    def __init__(self, city):
        assert isinstance(city, City)
        self.city = city

class Scientist:
    def __init__(self, name, dob):
        self.name = name
        self.dob = dob
        self.place_of_birth = PlaceOfBirth

class City:
    def __init__(self, name, country):
        self.name = name
        assert isinstance(country, Country)
        self.country = country

class Country:
    def __init__(self, name, population):
        self.name = name
        self.population = population

darwin = Scientist('Charles Darwin', '1809-02-12')
carver = Scientist('George Washington Carver', '1864')
dayhoff = Scientist('Margaret Dayhoff', '1925-03-11')
curie = Scientist('Marie Skłodowska Curie', '1867-11-07')


uk = Country('UK', 67330000)
usa = Country('USA', 331900000)
poland = Country('Poland', 37750000)

shrewsbury = City('Shrewsbury', uk)
diamond = City('Diamond', usa)
philly = City('Philadelphia', usa)
warsaw = City('Warsaw', poland)

darwin.place_of_birth = PlaceOfBirth(shrewsbury)
carver.place_of_birth = PlaceOfBirth(diamond)
dayhoff.place_of_birth = PlaceOfBirth(philly)
curie.place_of_birth = PlaceOfBirth(warsaw)



print(darwin.place_of_birth.city.name)
print(darwin.place_of_birth.city.country.name)

print(carver.place_of_birth.city.country.population)
print(dayhoff.place_of_birth.city.country.population)
usa.population = 331900001
print(carver.place_of_birth.city.country.population)
print(dayhoff.place_of_birth.city.country.population)

