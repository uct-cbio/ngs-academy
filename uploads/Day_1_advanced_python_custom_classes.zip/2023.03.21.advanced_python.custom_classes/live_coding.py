import csv
import pprint

class Sample:
    def __init__(self, sample_id, lineage):
        self.sample_id = sample_id
        self.lineage = lineage
        self.drugs = [] # drugs is agoing to be a list of Drug instances

class Drug:
    def __init__(self):
        self.drug_name = str
        self.susceptibility = str
        self.genes = []

'''
1. import the data
    a. read it into a python object (?)
2. iterate through the data (for loop)
3. create the data sturcture we want
    a. output = {'sample_id': [[aminoglycosdes, 'S', 'genes'], [esbls...]]}
    b. output = {'sample_id': {'drug':'aminoglycosides', 'suspcet':'R'}}
    c. output = {'sample_id': {'drug':'aminoglycosides', 'suspcet':'R'}}
    d. output = {'sample_id': Sample()}
4. print out the tables we want
'''

def read_infile(inhandle):
    # context manager
    with open(inhandle) as fi:
        records = csv.DictReader(fi)
        # generator rather than iterator
        output = list(records)
        #pprint.pprint(output)
        return output

def make_classes(records):
    # pprint.pprint(records)
    output_dictonary = {}
    for each_record in records:
        # print(each_record['sample'])
        sample_name = each_record['sample']
        sample_lineage = each_record['lineage']
        if sample_name in output_dictonary:
            output_dictonary[sample_name].genes.append(Gene())
        else:
            output_dictonary[sample_name] = Sample(sample_name, sample_lineage)
            output_dictonary[sample_name].genes.append(Gene())
        print('blah')
    pprint.pprint(output_dictonary)


def main():
    inhandle = '/Users/flashton/Google Drive/training/KEMRI training/2023.03.21.advanced_python.custom_classes/typhi_mykrobe.training.csv'
    records = read_infile(inhandle)
    make_classes(records)


main()

