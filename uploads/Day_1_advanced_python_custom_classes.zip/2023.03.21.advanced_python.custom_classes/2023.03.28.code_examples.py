
class BioSequence(object):
    """Biological sequence class with methods."""
    # The special method __init__() is run when the class is instantiated
    def __init__(self, seq="", material="dna"):
        """
        Instantiate Biosequence object with sequence and material.
        Material is either 'dna', 'rna', or 'protein'.
        """
        self.seq = seq
        self.material = material.lower()

    # Define a method
    def seq_len(self):
        """The length of the sequence."""
        return len(self.seq)


# Instantiate Biosequence
s = BioSequence(seq='ATGAAGGGTCC')

# Call the methods
print('The sequence has', s.seq_len(), 'bases.')


class Nucleotides(BioSequence):
    """Nucleotide sequences and related methods."""

    def T_marmur(self):
        """Melting temperature by Marmur rule of thumb."""
        seq_up = self.seq.upper()

        at_count = seq_up.count("A") + seq_up.count("T")
        gc_count = seq_up.count("G") + seq_up.count("C")

        return 2 * at_count + 4 * gc_count

# Instantiate object
s = Nucleotides('AAAGGTTTTTTTTTTTC', material='dna')

# Compute result
print(s.T_marmur())


class Gene():
    def __init__(self, gene_name, sequence):
        self.gene_name = gene_name
        self.sequence = sequence

my_gene = Gene('my_gene1', s)

print(my_gene.sequence.seq)

s.seq += 'ATGT'

print(my_gene.sequence.seq)



