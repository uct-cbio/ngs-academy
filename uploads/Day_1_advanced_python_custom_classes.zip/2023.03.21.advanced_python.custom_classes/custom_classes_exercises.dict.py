import csv
import pprint
# for each sample, print out the lineage it is, the drugs it is resistant to, the genes responsible for those resistances, and the evidence underpinning the idenficiations of those genes.


def read_infile(inhandle):
    output = []
    with open(inhandle) as fi:
        records = csv.DictReader(fi)
        output = list(records)
    return output


def make_dictionary_version(records):
    # pprint.pprint(records)
    output_dict = {}
    for each_record in records:
        if each_record['sample'] not in output_dict:
            output_dict[each_record['sample']] = {}
        else:
            pass
        assert each_record['drug'] not in output_dict[each_record['sample']]
        # if each_record['drug'] not in output_dict[each_record['sample']]:
        output_dict[each_record['sample']][each_record['drug']] = {}
        output_dict[each_record['sample']][each_record['drug']]['susceptibility'] = each_record['susceptibility']
        output_dict[each_record['sample']][each_record['drug']]['genes'] = each_record['genes']
        # else:
            # pass
    # pprint.pprint(output_dict)
    return output_dict


def dv_print_suscept(output_dict):
    drugs = ['aminoglycosides', 'beta-lactamases', 'ESBLs', 'macrolides', 'phenicols', 'sulfonamides', 'tetracyclines', 'trimethoprims']
    for sample in output_dict:
        output = [sample]
        for drug in drugs:
            output.append(output_dict[sample][drug]['susceptibility'])
            # print(sample, output_dict[drug]['susceptibility'])
        print(*output, sep = '\t')


def get_genes(gene_string):
    genes = gene_string.split(';')
    output = []
    for gene in genes:
        gene_details = gene.split(':')
        output.extend([gene_details[0], int(gene_details[1]), int(gene_details[2])])
    # print(output)
    return output


def dv_print_genes(output_dict):
    for sample in output_dict:
        # print(sample, output_dict[sample])
        for drug in output_dict[sample]:
            output = [sample, drug]
            # print(drug, output_dict[sample][drug])
            if output_dict[sample][drug]['genes'] != '':
                genes = get_genes(output_dict[sample][drug]['genes'])
                output += genes
                print(*output, sep = '\t')






def main():
    '''
    1. read in results
    2. group by sample name
        a. {sample_name:{drug_name:{genes:{gene_name:{}}, susceptibility:'R'}}
    '''
    inhandle = '/Users/flashton/Google Drive/training/KEMRI training/2023.03.21.advanced_python.custom_classes/typhi_mykrobe.training.csv'
    records = read_infile(inhandle)
    output_dict = make_dictionary_version(records)
    pprint.pprint(output_dict)
    # dv_print_suscept(output_dict)
    # dv_print_genes(output_dict)
    # todo - do the class version



if __name__ == '__main__':
    main()